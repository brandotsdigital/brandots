"use client"

import { useState } from "react"
import Image from "next/image"
import { Monitor, Settings, Smartphone, Database, Server, Cloud, ArrowRight } from "lucide-react"

const technologyCategories = [
  {
    id: "frontend",
    title: "Frontend Programming Languages",
    icon: Monitor,
    technologies: [
      { name: "React", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Vue.js", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Angular", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Next.js", logo: "/placeholder.svg?height=60&width=60" },
      { name: "TypeScript", logo: "/placeholder.svg?height=60&width=60" },
      { name: "JavaScript", logo: "/placeholder.svg?height=60&width=60" },
      { name: "HTML5", logo: "/placeholder.svg?height=60&width=60" },
      { name: "CSS3", logo: "/placeholder.svg?height=60&width=60" },
    ],
  },
  {
    id: "backend",
    title: "Backend Programming Languages",
    icon: Settings,
    technologies: [
      { name: ".NET", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Java", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Python", logo: "/placeholder.svg?height=60&width=60" },
      { name: "PHP", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Node.js", logo: "/placeholder.svg?height=60&width=60" },
      { name: "GO", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Ruby", logo: "/placeholder.svg?height=60&width=60" },
      { name: "C#", logo: "/placeholder.svg?height=60&width=60" },
    ],
  },
  {
    id: "mobile",
    title: "Mobile",
    icon: Smartphone,
    technologies: [
      { name: "React Native", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Flutter", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Swift", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Kotlin", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Xamarin", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Ionic", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Cordova", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Unity", logo: "/placeholder.svg?height=60&width=60" },
    ],
  },
  {
    id: "bigdata",
    title: "Big Data",
    icon: Database,
    technologies: [
      { name: "Apache Spark", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Hadoop", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Kafka", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Elasticsearch", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Apache Storm", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Cassandra", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Apache Flink", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Snowflake", logo: "/placeholder.svg?height=60&width=60" },
    ],
  },
  {
    id: "databases",
    title: "Databases / Data Storages",
    icon: Server,
    technologies: [
      { name: "MongoDB", logo: "/placeholder.svg?height=60&width=60" },
      { name: "PostgreSQL", logo: "/placeholder.svg?height=60&width=60" },
      { name: "MySQL", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Redis", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Oracle", logo: "/placeholder.svg?height=60&width=60" },
      { name: "SQLite", logo: "/placeholder.svg?height=60&width=60" },
      { name: "DynamoDB", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Firebase", logo: "/placeholder.svg?height=60&width=60" },
    ],
  },
  {
    id: "cloud",
    title: "Cloud DB, Warehouses And Storage",
    icon: Cloud,
    technologies: [
      { name: "AWS", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Azure", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Google Cloud", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Docker", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Kubernetes", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Jenkins", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Terraform", logo: "/placeholder.svg?height=60&width=60" },
      { name: "Vercel", logo: "/placeholder.svg?height=60&width=60" },
    ],
  },
]

export default function Technologies() {
  const [activeTab, setActiveTab] = useState("backend")

  const activeCategory = technologyCategories.find((cat) => cat.id === activeTab)

  return (
    <section id="technologies" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
            Tech Capabilities Driving Digital
            <br />
            Transformation For Our Clients
          </h2>
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-blue-400 rounded-3xl overflow-hidden shadow-2xl">
            <div className="grid lg:grid-cols-5 min-h-[500px]">
              {/* Left Sidebar - Technology Categories */}
              <div className="lg:col-span-2 p-8 lg:p-12">
                <div className="space-y-4">
                  {technologyCategories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setActiveTab(category.id)}
                      className={`w-full flex items-center justify-between p-4 rounded-xl transition-all duration-300 text-left group ${
                        activeTab === category.id
                          ? "bg-white/20 backdrop-blur-sm border border-white/30"
                          : "hover:bg-white/10 border border-transparent"
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-8 h-8 flex items-center justify-center transition-transform duration-300 ${
                            activeTab === category.id ? "scale-110" : "group-hover:scale-105"
                          }`}
                        >
                          <category.icon className="h-6 w-6 text-white" />
                        </div>
                        <span className="text-white font-medium text-lg">{category.title}</span>
                      </div>
                      {activeTab === category.id && <ArrowRight className="h-5 w-5 text-white animate-pulse" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Right Content - Technology Icons */}
              <div className="lg:col-span-3 bg-gray-50 p-8 lg:p-12">
                <div className="h-full flex flex-col">
                  <div className="mb-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{activeCategory?.title}</h3>
                    <div className="w-16 h-1 bg-orange-500 rounded-full"></div>
                  </div>

                  <div className="flex-1 flex items-center">
                    <div className="w-full">
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                        {activeCategory?.technologies.map((tech, index) => (
                          <div
                            key={tech.name}
                            className="group text-center transform transition-all duration-300 hover:scale-110"
                            style={{
                              animationDelay: `${index * 100}ms`,
                            }}
                          >
                            <div className="w-16 h-16 mx-auto mb-4 bg-white rounded-2xl shadow-lg flex items-center justify-center group-hover:shadow-xl transition-all duration-300 border border-gray-100">
                              <Image
                                src={tech.logo || "/placeholder.svg"}
                                alt={tech.name}
                                width={40}
                                height={40}
                                className="w-10 h-10 object-contain"
                              />
                            </div>
                            <h4 className="font-semibold text-gray-900 text-sm group-hover:text-orange-500 transition-colors">
                              {tech.name}
                            </h4>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Technology Expertise Stats */}
        <div className="mt-20 text-center">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">50+</div>
              <div className="text-gray-400 font-medium">Technologies Mastered</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">100%</div>
              <div className="text-gray-400 font-medium">Latest Frameworks</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">24/7</div>
              <div className="text-gray-400 font-medium">Technical Support</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">9+</div>
              <div className="text-gray-400 font-medium">Years Experience</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
