import Image from "next/image"
import Link from "next/link"
import { Calendar, User, ArrowRight, Clock, Eye } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const blogPosts = [
  {
    title: "The Future of Mobile App Development in 2024",
    excerpt:
      "Explore the latest trends and technologies shaping the mobile app development landscape, from AI integration to cross-platform solutions.",
    image: "/placeholder.svg?height=300&width=500",
    author: "John Doe",
    date: "March 15, 2024",
    readTime: "8 min read",
    views: "2.5K",
    category: "Mobile Development",
    slug: "future-mobile-app-development-2024",
    featured: true,
  },
  {
    title: "AI-Powered Mobile Apps: Transforming User Experiences",
    excerpt:
      "Discover how artificial intelligence is revolutionizing mobile applications and creating more personalized, intelligent user experiences.",
    image: "/placeholder.svg?height=300&width=500",
    author: "Jane Smith",
    date: "March 12, 2024",
    readTime: "6 min read",
    views: "1.8K",
    category: "AI & Technology",
    slug: "ai-powered-mobile-apps",
    featured: false,
  },
  {
    title: "React Native vs Flutter: Which Framework to Choose in 2024",
    excerpt:
      "A comprehensive comparison of React Native and Flutter to help you make the right choice for your next mobile app project.",
    image: "/placeholder.svg?height=300&width=500",
    author: "Mike Johnson",
    date: "March 10, 2024",
    readTime: "10 min read",
    views: "3.2K",
    category: "Development",
    slug: "react-native-vs-flutter-2024",
    featured: false,
  },
  {
    title: "Mobile App Security: Best Practices for 2024",
    excerpt:
      "Essential security practices every mobile app developer should implement to protect user data and ensure app integrity.",
    image: "/placeholder.svg?height=300&width=500",
    author: "Sarah Wilson",
    date: "March 8, 2024",
    readTime: "7 min read",
    views: "1.5K",
    category: "Security",
    slug: "mobile-app-security-best-practices",
    featured: false,
  },
  {
    title: "The Rise of Super Apps: Building All-in-One Mobile Solutions",
    excerpt:
      "Learn about the super app trend and how to build comprehensive mobile platforms that offer multiple services in one application.",
    image: "/placeholder.svg?height=300&width=500",
    author: "David Brown",
    date: "March 5, 2024",
    readTime: "9 min read",
    views: "2.1K",
    category: "Strategy",
    slug: "rise-of-super-apps",
    featured: false,
  },
  {
    title: "Mobile App Monetization Strategies That Actually Work",
    excerpt:
      "Proven monetization strategies for mobile apps, from freemium models to subscription services and in-app advertising.",
    image: "/placeholder.svg?height=300&width=500",
    author: "Emily Davis",
    date: "March 3, 2024",
    readTime: "5 min read",
    views: "1.9K",
    category: "Business",
    slug: "mobile-app-monetization-strategies",
    featured: false,
  },
]

const categories = ["All", "Mobile Development", "AI & Technology", "Development", "Security", "Strategy", "Business"]

export default function Blog() {
  return (
    <section id="blog" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-block bg-orange-100 text-orange-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Insights & Blog
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Latest insights on <span className="text-orange-500">mobile app development</span> and technology trends
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Stay updated with the latest mobile app development trends, industry insights, and best practices. Our
            expert team shares valuable knowledge to help you make informed decisions about your mobile app development
            projects.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category, index) => (
            <button
              key={index}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                index === 0
                  ? "bg-orange-500 text-white shadow-lg"
                  : "bg-white text-gray-600 hover:bg-orange-50 hover:text-orange-500 shadow-sm"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Featured Post */}
        {blogPosts
          .filter((post) => post.featured)
          .map((post, index) => (
            <div key={index} className="mb-16">
              <Card className="overflow-hidden shadow-2xl border-0 bg-white">
                <div className="grid lg:grid-cols-2 gap-0">
                  <div className="relative overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={500}
                      height={300}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4 bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                      Featured
                    </div>
                  </div>
                  <CardContent className="p-8 lg:p-12 flex flex-col justify-center">
                    <div className="space-y-6">
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{post.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{post.date}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{post.readTime}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Eye className="h-4 w-4" />
                          <span>{post.views}</span>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div className="inline-block bg-orange-100 text-orange-600 px-3 py-1 rounded-full text-sm font-medium">
                          {post.category}
                        </div>
                        <h3 className="text-2xl md:text-3xl font-bold text-gray-900 leading-tight">{post.title}</h3>
                        <p className="text-gray-600 leading-relaxed text-lg">{post.excerpt}</p>
                      </div>
                      <Link
                        href={`/blog/${post.slug}`}
                        className="inline-flex items-center text-orange-500 hover:text-orange-600 font-semibold text-lg group"
                      >
                        Read Full Article
                        <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                      </Link>
                    </div>
                  </CardContent>
                </div>
              </Card>
            </div>
          ))}

        {/* Regular Posts */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts
            .filter((post) => !post.featured)
            .map((post, index) => (
              <Card
                key={index}
                className="group overflow-hidden hover:shadow-2xl transition-all duration-500 border-0 shadow-lg hover:-translate-y-2"
              >
                <div className="relative overflow-hidden">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    width={500}
                    height={300}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {post.category}
                  </div>
                </div>
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <User className="h-4 w-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{post.date}</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 leading-tight group-hover:text-orange-500 transition-colors">
                    <Link href={`/blog/${post.slug}`}>{post.title}</Link>
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">{post.excerpt}</p>
                  <div className="flex items-center justify-between pt-4">
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{post.readTime}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Eye className="h-4 w-4" />
                        <span>{post.views}</span>
                      </div>
                    </div>
                    <Link
                      href={`/blog/${post.slug}`}
                      className="text-orange-500 hover:text-orange-600 font-medium text-sm group-hover:underline"
                    >
                      Read More →
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>

        <div className="text-center mt-12">
          <Button
            size="lg"
            className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-full font-semibold"
          >
            View All Articles
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
